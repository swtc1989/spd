#!/bin/sh
make autoconf
